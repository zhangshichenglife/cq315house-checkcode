from img_similar import *
from img_quzao import *
import os
from uuid import uuid1
from PIL import Image


def get_img_dir(img1_path, i, color_threshold=164, similar_threshold=0.9):

    img1 = Image.open(img1_path)
    img1_0 = remove_pixel(img1, threshold)
    img1_1 = remove_noise(img1_0, 50, 255)

    path0 = './check_code_split/first'
    for filelist in os.walk(path0, topdown=False):
        for filename in filelist[2]:
            path2 = path0 + '/' + filename
            # print(path2)

            img2 = Image.open(path2)
            img2_0 = remove_pixel(img2, color_threshold)
            img2_1 = remove_noise(img2_0, 50, 255)
            similar = get_similar_by_subtract(img1_1, img2_1)

            if similar > similar_threshold:
                middle_path = './check_code_split/third/' + str(i)
                if not os.path.exists(middle_path):
                    os.makedirs(middle_path)
                save_path = middle_path + '/' + str(uuid1()) + '.gif'
                img2_1.save(save_path)


if __name__ == '__main__':
    img1_path = './check_code_split/third/611a6a1a-fd9f-11e8-a07a-70c94edd0834.gif'
    i = 9
    get_img_dir(img1_path, i)
