import requests
from uuid import uuid1
import time


def get_content(url):                                                   # get the content of img
    try:
        response = requests.get(url)
        return response.content
    except Exception:
        print('img downloads fail')
        get_content(url)


def save_img(content):                                                  # save the content of img into gif
    path = './check_code_split/downloaded/' + str(uuid1()) + '.gif'
    with open(path, 'wb') as f:
        f.write(content)
        f.close()


if __name__ == '__main__':                                             # download img by circulate 100
    for i in range(100):
        print(i)
        url = 'http://www.cq315house.com/315web/YanZhengCode/ValidCode.aspx'
        content = get_content(url)
        save_img(content)
        time.sleep(2)
