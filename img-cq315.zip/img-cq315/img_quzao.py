from PIL import Image
import numpy as np


def remove_pixel(img, threshold=164):                       # remove the light pixel by the threshold of color shade
    imgL = img.convert('L')                             # get black-white img

    table = []
    for i in range(256):
        if i < threshold:
            table.append(0)
        else:
            table.append(1)

    new_img = imgL.point(table, '1')
    return new_img


def remove_noise(img, threshold=164, input_color=255):         # remove the isolated plots
    data = img.getdata()                               # get the data of img
    w, h = img.size
    matrix = np.array(data).reshape(w, h)              # make the img data to matrix
    black_point = 0

    for x in range(1, w-1):                            # adjust isolation
        for y in range(1, h-1):
            top_pixel = matrix[x][y+1]
            down_pixel = matrix[x][y-1]
            right_pixel = matrix[x-1][y]
            left_pixel = matrix[x+1][y]

            if top_pixel < threshold:
                black_point += 1
            if down_pixel < threshold:
                black_point += 1
            if right_pixel < threshold:
                black_point += 1
            if left_pixel < threshold:
                black_point += 1

            if black_point < 1:
                img.putpixel((x, y), input_color)
    return img


def remove_frame_noise(img, input_color=255):               # remove the noise plots on the frame of img
    w, h = img.size

    for x in range(w):
        img.putpixel((x, 0), input_color)
        img.putpixel((x, h-1), input_color)
    for y in range(h):
        img.putpixel((0, y), input_color)
        img.putpixel((w-1, y), input_color)

    return img


def img_no_noise(img):
    img1 = remove_pixel(img)
    img2 = remove_noise(img1)
    img3 = remove_frame_noise(img2)
    return img3







