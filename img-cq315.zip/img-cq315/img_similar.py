from PIL import Image
import os
import numpy as np
from img_quzao import *

def get_mean_similar(img1, path, get_similar):

    similar_list = []
    for file_dir in os.walk(path, topdown=False):
        for filename in file_dir[2]:
            img_path = path + '/' + filename
            img2 = Image.open(img_path)
            similar = get_similar(img1, img2)
            similar_list.append(similar)


    mean_similar = sum(similar_list)/len(similar_list)

    #print('check code merge with {} silimar is :'.format(path[-1]), str(mean_similar))
    return mean_similar


def get_similar_num(img, merge_path, get_similar):

    mean_similar_list = []
    root_path = []
    for root, dirs, files in list(os.walk(merge_path, topdown=False)):
        if root != merge_path:
            root_path.append(root)
            mean_similar = get_mean_similar(img, root, get_similar)
            mean_similar_list.append(mean_similar)


    max_similar = max(mean_similar_list)
    num = mean_similar_list.index(max_similar)
    path_rst = root_path[num]

    return path_rst[-1]


def get_similar_by_subtract(img1, img2): # get the similarity by subtract

    img1 = img_no_noise(img1)
    img2 = img_no_noise(img2)

    data1 = img1.getdata()
    data2 = img2.getdata()
    out_list = []
    list1 = list(data1)
    list2 = list(data2)

    black_point = 1

    if len(list1) == len(list2):
        for n in range(len(list1)):
            out_list.append(abs(list1[n] - list2[n]))
            if list1[n] + list2[n] > 255:
                black_point += 1
    else:
        print('the img size is not equal')

    similar = 1 - sum(out_list)/(black_point*255)

    return similar


def get_similar_by_eig(img1, img2):                         # get the similarity by the eig of matrix
    w, h = img1.sizw
    data1 = img1.getdata()
    data2 = img2.getdata()
    matrix1 = np.array(data1).reshape(w, h)
    matrix2 = np.array(data2).reshape(w, h)
    v1 = np.linalg.eig(matrix1)[2].T
    v2 = np.linalg.eig(matrix1)[2].T
    ma1 = [[v[i][j] ** 2 for j in range(len(v1[i]))] for i in range(len(v1))]
    pass










