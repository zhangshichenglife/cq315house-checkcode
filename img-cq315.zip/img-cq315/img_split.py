from PIL import Image
import os
import uuid


def split_img_into_box(img):                                # split img to five piece

    box1 = (0, 0, 23, 25)                          # get the box of img
    box2 = (23, 0, 54, 25)
    box3 = (54, 0, 72, 25)
    box4 = (72, 0, 100, 25)
    box5 = (100, 0, 126, 25)

    img1 = img.crop(box1)                          # split the img by box
    img2 = img.crop(box2)
    img3 = img.crop(box3)
    img4 = img.crop(box4)
    img5 = img.crop(box5)
    return  {
        'img1': img1,
        'img2': img2,
        'img3': img3,
        'img4': img4,
        'img5': img5
    }


def save_split_img(img):
    img_list = split_img_into_box(img)

    img1 = img_list.get('img1')
    img2 = img_list.get('img2')
    img3 = img_list.get('img3')
    img4 = img_list.get('img4')
    img5 = img_list.get('img5')

    path0 = './check_code_split/splited'           # save base path

    if not os.path.exists(path0 + '/first'):       # adjust the existence of the save dir
        os.mkdir(path0 + '/first')
    if not os.path.exists(path0 + '/second'):
        os.mkdir(path0 + '/second')
    if not os.path.exists(path0 + '/third'):
        os.mkdir(path0 + '/third')
    if not os.path.exists(path0 + '/four'):
        os.mkdir(path0 + '/four')
    if not os.path.exists(path0 + '/five'):
        os.mkdir(path0 + '/five')

    path1 = path0 + '/first' + '/' + str(uuid.uuid1()) + '.gif'   # get save path by uuid
    path2 = path0 + '/second' + '/' + str(uuid.uuid1()) + '.gif'
    path3 = path0 + '/third' + '/' + str(uuid.uuid1()) + '.gif'
    path4 = path0 + '/four' + '/' + str(uuid.uuid1()) + '.gif'
    path5 = path0 + '/five' + '/' + str(uuid.uuid1()) + '.gif'

    img1.save(path1, 'gif')                                       # save the splited img
    img2.save(path2, 'gif')
    img3.save(path3, 'gif')
    img4.save(path4, 'gif')
    img5.save(path5, 'gif')


if __name__ == '__main__':
    for i in os.walk('./check_code_split/downloaded', topdown=False):
        for filename in i[2]:
            path = './check_code_split/downloaded/' + filename
            img = Image.open(path)
            save_split_img(img)








