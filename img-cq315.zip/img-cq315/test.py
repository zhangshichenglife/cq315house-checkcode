from downloader import *
from img_similar import *
from PIL import Image
import time
from img_split import *
from img_quzao import *

def test_code():
    url = 'http://www.cq315house.com/315web/YanZhengCode/ValidCode.aspx'
    content = get_content(url)
    print('验证码下载完成')
    with open('middleImg.gif', 'wb') as f:
        f.write(content)
        f.close()

    img = Image.open('middleImg.gif')
    img.show()
    time.sleep(0.5)
    img_list = split_img_into_box(img)
    img1 = img_list.get('img1')
    img2 = img_list.get('img2')
    img3 = img_list.get('img3')

    # img1.save('img1.gif')
    # img2.save('img2.gif')
    # img3.save('img3.gif')

    merge_path1 = r'.\check_code_split\first'
    num_str_1 = get_similar_num(img1, merge_path1, get_similar_by_subtract)
    print('the first str1 is :', num_str_1)

    merge_path2 = r'.\check_code_split\second'
    str_2 = get_similar_num(img2, merge_path2, get_similar_by_subtract)
    if str_2 == '0':
        str_2 = '-'

    else:
        str_2 = '+'
    print('the second str2 is :', str_2)

    merge_path3 = r'.\check_code_split\third'
    num_str_3 = get_similar_num(img3, merge_path3, get_similar_by_subtract)

    check_code_str = num_str_1 + str_2 + num_str_3
    print('the third str3 is :', num_str_3)

    print('the check code is :', check_code_str + '=')

    rst = eval(check_code_str)
    return rst


if __name__ == '__main__':
    while True:
        rst = test_code()
        print('the rst is :', rst)



